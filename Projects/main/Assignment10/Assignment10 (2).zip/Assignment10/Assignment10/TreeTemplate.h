//#include <iostream>
//
//#pragma once
//
//template<class T>
//class TreeNode {
//private:
//	TreeNode* left = nullptr;
//	TreeNode* right = nullptr;
//	T value = T();
//public:
//	TreeNode(){}
//	TreeNode* getLeft() {
//		return left;
//	}
//	TreeNode* getRight() {
//		return right;
//	}
//
//	void setValue(T pValue) {
//		value = pValue;
//	}
//	T getValue() const {
//		return value;
//	}
//
//
//};
//
////[Recursive]
//template<class T>
//void printTree() {
//
//}